<!DOCTYPE html>
<html>
<head>

  <style>
    #thanks {
      font-size: 30px;
      color: white;
      text-shadow: 1px 1px 2px black, 0 0 25px blue, 0 0 5px darkblue;
      text-align: center;
    }
    #description {
      font-size: 20px;
      color: white;
      text-shadow: 1px 1px 2px black, 0 0 25px red, 0 0 5px red;
      text-align: right;
      margin-right: 20px;
    }
  </style>
</head>
<body style="background:url(../Verify/emailverify.jpg) no-repeat center fixed;">
<p id="thanks">Thanks for your Email Verification</p>

<form action="confirm.php" method="post">
Input Your Verify Code here: 
<input type="text" name="confirmCode" style="margin-left:20px;">
<input type="submit" value="Confirm" style="margin-left:20px;">
</form>

<p id="description">Your can use Dooglee Site and Apps in the next time!</p>
</body>
</html>
