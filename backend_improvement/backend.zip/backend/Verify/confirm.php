<html>
<head>

<script language="javascript" type="text/javascript"> 
function windowClose() { 
window.open('','_parent',''); 
window.close();
} 
</script>

</head>
<body>

<?php
$con=$_POST["confirmCode"];
$username="crazyloveme";
$password="qmhHN&.beDIU";
$dbname="dooglee_data";
$servername = "localhost";
// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

$sql = "SELECT * FROM users WHERE user_status = $con";
$result = $conn->query($sql);

if ($result->num_rows > 0) {

  while($row = $result->fetch_assoc()) {
        if($row['user_status'] == $con){
            $sql = "UPDATE users SET user_status='1' WHERE user_status = $con";
            $conn->query($sql);
//    echo "Congratulation your email is verified now !";
	echo "<script>windowClose();</script>";
		
        }
    }
  
} else {
    echo "Invalided your Email Verifed!";
}
mysql_close();
?>

</body>
</html>