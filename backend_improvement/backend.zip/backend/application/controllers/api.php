<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Credentials: true ");
header("Access-Control-Allow-Methods: OPTIONS, GET, POST");
header("Access-Control-Allow-Headers: Content-Type, Depth, User-Agent, X-File-Size, X-Requested-With, If-Modified-Since, X-File-Name, Cache-Control");

if (!defined('BASEPATH')) exit('No direct script access allowed');

class Api extends CI_Controller {

    public function __construct() {
        parent::__construct();

/*        $this->data = json_decode(file_get_contents('php://input'), TRUE);
		echo $this->data;
*/
        $valid = true;/*!(
        		empty($_SERVER['CONTENT_TYPE']) ||
        		$_SERVER['CONTENT_TYPE'] != 'application/json' ||
        		!(isset($_SERVER['HTTP_API_KEY']) && $_SERVER['HTTP_API_KEY'] == config_item('api_key')));

*/
        if($valid) {
        	$this->data = json_decode(file_get_contents('php://input'), TRUE);
            $valid = !!count($this->data);
        }
        if(!$valid) {
        	echo "Invalid Request";
        	exit;
        }

    }

	public function user_signup() {
    	$request_fields = array('user_firstname', 'user_lastname', 'user_streetaddress','user_unitnumber','user_city','user_state','user_country',
			'user_postalcode','user_email','user_phonenumber','user_password','user_photo');
        $request_form_success = true;
        foreach ($request_fields as $request_field) {
            if (!isset($this->data[$request_field]) || $this->data[$request_field] == '') {
                $request_form_success = false;
                break;
            }
        }
        if (!$request_form_success) {
            $response['status'] = 0;
            $response['msg'] = config_item('msg_fill_form');
        } else {
            $response = $this->api_model->user_signup($this->data);
        }
        echo json_encode($response);
    }
    
   
public function userinfo_update() {
    	$request_fields = array('user_firstname', 'user_lastname', 'user_streetaddress','user_unitnumber','user_city','user_state','user_country',
			'user_postalcode','user_phonenumber','user_email','user_photo');
        $request_form_success = true;
        foreach ($request_fields as $request_field) {
            if (!isset($this->data[$request_field]) || $this->data[$request_field] == '') {
                $request_form_success = false;
                break;
            }
        }
        if (!$request_form_success) {
            $response['status'] = 0;
            $response['msg'] = config_item('msg_fill_form');
        } else {
            $response = $this->api_model->userinfo_update($this->data);
        }
        echo json_encode($response);
    }
    
public function email_verify() {

     	$request_fields = array('user_email', 'user_status');
		$request_form_success = true;

		foreach ($request_fields as $request_field){
			if (!isset($this->data[$request_field]) || $this->data[$request_field] == '') {
                $request_form_success = false;
                break;
			}
		}
        if (!$request_form_success) {
            $response['status'] = 0;
            $response['msg'] = config_item('msg_fill_form');
        } else {
            $response = $this->api_model->email_verify($this->data);
        }
        echo json_encode($response);
    }
public function user_login() {

     	$request_fields = array('user_email', 'user_password');
		$request_form_success = true;

		foreach ($request_fields as $request_field){
			if (!isset($this->data[$request_field]) || $this->data[$request_field] == '') {
                $request_form_success = false;
                break;
			}
		}
        if (!$request_form_success) {
            $response['status'] = 0;
            $response['msg'] = config_item('msg_fill_form');
        } else {
            $response = $this->api_model->user_login($this->data);
        }
        echo json_encode($response);
    }

public function forget_password(){
     	$request_fields = array('user_email','user_password');
		$request_form_success = true;

		foreach ($request_fields as $request_field){
			if (!isset($this->data[$request_field]) || $this->data[$request_field] == '') {
                $request_form_success = false;
                break;
			}
		}
        if (!$request_form_success) {
            $response['status'] = 0;
            $response['msg'] = config_item('msg_fill_form');
        } else {
            $response = $this->api_model->forget_password($this->data);
        }
        echo json_encode($response);
    }

public function post_task(){
     	$request_fields = array('task_email','task_homeaddress','task_newaddress','task_description','task_budget','task_latitude','task_longitude','task_sel');
		$request_form_success = true;

		foreach ($request_fields as $request_field){
			if (!isset($this->data[$request_field]) || $this->data[$request_field] == '') {
                $request_form_success = false;
                break;
			}
		}
        if (!$request_form_success) {
            $response['status'] = 0;
            $response['msg'] = config_item('msg_fill_form');
        } else {
            $response = $this->api_model->post_task($this->data);
        }
        echo json_encode($response);
}






public function search_task(){
     	$request_fields = array('worker_email','worker_latitude','worker_longitude');
		$request_form_success = true;

		foreach ($request_fields as $request_field){
			if (!isset($this->data[$request_field]) || $this->data[$request_field] == '') {
                $request_form_success = false;
                break;
			}
		}
        if (!$request_form_success) {
            $response['status'] = 0;
            $response['msg'] = config_item('msg_fill_form');
        } else {
            $response = $this->api_model->search_task($this->data);
        }
        echo json_encode($response);
}


public function view_task(){
     	$request_fields = array('user_email');
		$request_form_success = true;

		foreach ($request_fields as $request_field){
			if (!isset($this->data[$request_field]) || $this->data[$request_field] == '') {
                $request_form_success = false;
                break;
			}
		}
        if (!$request_form_success) {
            $response['status'] = 0;
            $response['msg'] = config_item('msg_fill_form');
        } else {
            $response = $this->api_model->view_task($this->data);
        }
        echo json_encode($response);
}

public function post_proposal(){
     	$request_fields = array('worker_email','task_id');
		$request_form_success = true;

		foreach ($request_fields as $request_field){
			if (!isset($this->data[$request_field]) || $this->data[$request_field] == '') {
                $request_form_success = false;
                break;
			}
		}
        if (!$request_form_success) {
            $response['status'] = 0;
            $response['msg'] = config_item('msg_fill_form');
        } else {
            $response = $this->api_model->post_proposal($this->data);
        }
        echo json_encode($response);
}




public function view_proposal(){
     	$request_fields = array('task_id');
		$request_form_success = true;

		foreach ($request_fields as $request_field){
			if (!isset($this->data[$request_field]) || $this->data[$request_field] == '') {
                $request_form_success = false;
                break;
			}
		}
        if (!$request_form_success) {
            $response['status'] = 0;
            $response['msg'] = config_item('msg_fill_form');
        } else {
            $response = $this->api_model->view_proposal($this->data);
        }
        echo json_encode($response);
}





public function get_clientinfo(){
     	$request_fields = array('client_email');
		$request_form_success = true;

		foreach ($request_fields as $request_field){
			if (!isset($this->data[$request_field]) || $this->data[$request_field] == '') {
                $request_form_success = false;
                break;
			}
		}
        if (!$request_form_success) {
            $response['status'] = 0;
            $response['msg'] = config_item('msg_fill_form');
        } else {
            $response = $this->api_model->get_clientinfo($this->data);
        }
        echo json_encode($response);
}


public function user_rate_view(){
		$request_fields = array('user_email');
		$request_form_success = true;

		foreach ($request_fields as $request_field){
			if (!isset($this->data[$request_field]) || $this->data[$request_field] == '') {
                $request_form_success = false;
                break;
			}
		}
        if (!$request_form_success) {
            $response['status'] = 0;
            $response['msg'] = config_item('msg_fill_form');
        } else {
            $response = $this->api_model->user_rate_view($this->data);
        }
        echo json_encode($response);
}

public function user_rate_update(){
		$request_fields = array('user_email','user_rate','task_budget');
		$request_form_success = true;

		foreach ($request_fields as $request_field){
			if (!isset($this->data[$request_field]) || $this->data[$request_field] == '') {
                $request_form_success = false;
                break;
			}
		}
        if (!$request_form_success) {
            $response['status'] = 0;
            $response['msg'] = config_item('msg_fill_form');
        } else {
            $response = $this->api_model->user_rate_update($this->data);
        }
        echo json_encode($response);
}



public function completedID_update(){
     		$request_fields = array('task_id');
		$request_form_success = true;

		foreach ($request_fields as $request_field){
			if (!isset($this->data[$request_field]) || $this->data[$request_field] == '') {
                $request_form_success = false;
                break;
			}
		}
        if (!$request_form_success) {
            $response['status'] = 0;
            $response['msg'] = config_item('msg_fill_form');
        } else {
            $response = $this->api_model->completedID_update($this->data);
        }
        echo json_encode($response);
}



public function send_email(){
     	$request_fields = array('from_email','to_email','email_content');
		$request_form_success = true;

		foreach ($request_fields as $request_field){
			if (!isset($this->data[$request_field]) || $this->data[$request_field] == '') {
                $request_form_success = false;
                break;
			}
		}
        if (!$request_form_success) {
            $response['status'] = 0;
            $response['msg'] = config_item('msg_fill_form');
        } else {
            $response = $this->api_model->send_email($this->data);
        }
        echo json_encode($response);
}




}
