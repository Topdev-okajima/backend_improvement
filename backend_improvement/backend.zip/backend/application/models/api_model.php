<?php
if (!defined('BASEPATH')) exit('No direct script access allowed');

class Api_model extends CI_Model {

    public function __construct() {

    }


public function user_signup($params) {
        $result = array();
        $data = array();
        $status = 0;
        $msg = '';
          $request_field_prefix = 'user_';
        	// Manual Sign Up
          $request_fields = array('firstname', 'lastname', 'streetaddress','unitnumber','city','state','country','postalcode','email','phonenumber','password','photo');
        	foreach ($request_fields as $request_field) {
        		$request_field_new = $request_field_prefix . $request_field;
        		if(isset($params[$request_field_new])) {
        			$data[$request_field_new] = $params[$request_field_new];
        		}
        	}
        	
        	$firstname=$data['user_firstname'];
        	$lastname=$data['user_lastname'];
        	$email=$data['user_email'];
        	$phonenumber=$data['user_phonenumber'];
        	
	if (!preg_match("/^[a-zA-Z ]*$/",$firstname) ||!preg_match("/^[a-zA-Z ]*$/",$lastname) || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
  	$msg = "There are Format Errors for  Name,Email, Please check it again!"; 
  	$status=0;
	}else{     	
              	$query_user_email = $this->db->get_where('users', array('user_email' => $data['user_email']));
        	if($query_user_email->num_rows() > 0) {
        		$status = 3;
        		$msg = 'This email is already registered';
        	} else {

		if(isset($params['user_photo']) && $params['user_photo'] != '') {
                $image_name = rand(10000,1000000) . '.jpg';
                $image_url = config_item('path_media_user_photo').$image_name;
                $binary = base64_decode($params['user_photo']);
                header('Content-Type: bitmap; charset=utf-8');
                $file = fopen($image_url, 'w');
                if($file) {
                  fwrite($file, $binary);
                } else {
                  $status = 3;
                  $msg = 'File Upload failed';
                }
                fclose($file);
                if($status < 2) {
                  $status = 1;
                  $data['user_photo'] = base_url().$image_url;
                }
              }


             $verifyCode=rand(1000,9999);
             $data['user_status']=$verifyCode;
             $data['user_password']=md5($params['user_password']);
        	$success=$this->db->insert('users', $data);
      		if($success==true){
      		
              
		
		$headers = "From: dreamstar@dooglee.com\r\n";
		$headers .= "Reply-To: dreamstar@dooglee.com\r\n";
		$headers .= "Return-Path: dreamstar@dooglee.com\r\n";
		$headers .= "CC: sombodyelse@example.com\r\n";
		$headers .= "BCC: hidden@example.com\r\n";
		
              $to_email=$data['user_email'];
              $subject="Email Verification if you desire!";
              $verifyEmail = "Dear User,\n Please click on the below activation link to verify your email address.\n http://doogback.dooglee.com/backend/Verify/  \n If you have any questions to verify and use ,please contact us(https://www.dooglee.com/)\n Thanks for your invitaion! \n Hope your business successfully! \n Your Verify Code is ".$verifyCode;
              // use wordwrap() if lines are longer than 70 characters
              $verifyEmail = wordwrap($verifyEmail,70);
              // send email
               mail($to_email,$subject,$verifyEmail,$headers); 
		$status = 1;
		$msg = "Verify your Email!";

        		} else {
        			$status = 2;
        			$msg = 'User sign up Failed';
        		}
        	}
        }	
        $result['status'] = $status;
        $result['msg'] = $msg;
        return $result;
    }
	


	public function userinfo_update($params) {
        $result = array();
        $data = array();
        $status = 0;
        $msg = '';
          $request_field_prefix = 'user_';
        	// Manual Sign Up
          $request_fields = array('firstname', 'lastname', 'streetaddress','unitnumber','city','state','country','postalcode','email','phonenumber','photo');
        	foreach ($request_fields as $request_field) {
        		$request_field_new = $request_field_prefix . $request_field;
        		if(isset($params[$request_field_new])) {
        			$data[$request_field_new] = $params[$request_field_new];
        		}
        	}
        	
        	$firstname=$data['user_firstname'];
        	$lastname=$data['user_lastname'];
        	$email=$data['user_email'];
        	$phonenumber=$data['user_phonenumber'];
        	
	if (!preg_match("/^[a-zA-Z ]*$/",$firstname) ||!preg_match("/^[a-zA-Z ]*$/",$lastname) || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
  	$msg = "There are Format Errors for  Name,Email, Please check it again!"; 
  	$status=0;
	}else{     	
              	$query_user_email = $this->db->get_where('users', array('user_email' => $data['user_email']));
        	if($query_user_email->num_rows() > 0) {
        	
        	
		if(isset($params['user_photo']) && $params['user_photo'] != '') {
                $image_name = rand(10000,1000000) . '.jpg';
                $image_url = config_item('path_media_user_photo').$image_name;
                $binary = base64_decode($params['user_photo']);
                header('Content-Type: bitmap; charset=utf-8');
                $file = fopen($image_url, 'w');
                if($file) {
                  fwrite($file, $binary);
                } else {
                  $status = 3;
                  $msg = 'File Upload failed';
                }
                fclose($file);
                if($status < 2) {
                  $status = 1;
                  $data['user_photo'] = base_url().$image_url;
                }
              }
        	
        $this->db->update('users', array('user_firstname'=>$params['user_firstname'], 'user_lastname'=>$params['user_lastname'], 'user_streetaddress'=>$params['user_streetaddress'],'user_unitnumber'=>$params['user_unitnumber'],'user_city'=>$params['user_city'],'user_state'=>$params['user_state'],'user_country'=>$params['user_country'],'user_postalcode'=>$params['user_postalcode'],'user_phonenumber'=>$params['user_phonenumber'],'user_photo'=>$data['user_photo']), array('user_email' => $params['user_email']));
        	       	
        		$status = 1;
        		$msg = 'User Info was Updated successfully!';
        	} else {

        		$status = 2;
        		$msg = 'User Info was not Updated unsuccessfully!';

 
        	}
        }	
        $result['status'] = $status;
        $result['msg'] = $msg;
        return $result;
    }
	
	
	
	
	public function email_verify($params){
		$result = array();
		$status = 0;
		$data=array();
		$msg = '';
		$query = $this->db->get_where('users', array('user_email'=>$params['user_email'], 'user_status'=>$params['user_status']));
		if($query->num_rows() > 0){
			$status=1;
			$msg='Email verified successfully!';
			$data=$query->row_array();
		}else{
			$status = 2;
			$msg = 'Email verified invaild!';
		}
		$result['status'] = $status;
		$result['msg'] = $msg;
		$result['data']=$data;
		return $result;
	}

	public function user_login($params){
		$result = array();
		$status = 0;
		$data=array();
		$msg = '';
		
		//Email Format Check//////////
		$email=$params['user_email'];
		if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
  		$msg = "Invalid email format";
  		$status=0; 
		}else{		
		$query = $this->db->get_where('users', array('user_email'=>$params['user_email'], 'user_password'=>md5($params['user_password'])));
		if($query->num_rows() > 0){
      $query_user_status = $this->db->get_where('users', array('user_email'=>$params['user_email'],'user_status'=>'1'));
      if($query_user_status->num_rows() > 0){
        $status = 1;
        $msg = 'success';
		$data=$query_user_status->row_array();
      }else {
        $status=3;
        $msg='please confirm your verify code!';
      }

		}else{
			$status = 2;
			$msg = 'Invalid email or password.';
		}
		
		}	
		$result['status'] = $status;
		$result['msg'] = $msg;
		$result['data']=$data;
		return $result;
		
	}

public function forget_password($params){
	$result=array();
	$data=array();
	$status=0;
	$msg='';
	
	//Email Format Check//////////
	$email=$params['user_email'];
	if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
  	$msg = "Invalid email format";
  	$status=0;
  	}else{ 
	$query_user_email=$this->db->get_where('users',array('user_email'=>$params['user_email']));
	if($query_user_email->num_rows()>0){
		$data=$query_user_email->row_array();
		if($data['user_status']=='1'){
            $this->db->update('users', array('user_password' => md5($params['user_password'])), array('user_email' => $params['user_email']));
			$status=1;
			$msg='success';
		}else{
			$status=2;
			$msg='You are not verified!';
		}
	}else {
		$status=3;
		$msg='You are a unregistered user!';
	}
	}
	
	$result['status']=$status;
	$result['msg']=$msg;
	return $result;

}

public function post_task($params){
	$result=array();
	$data=array();
	$status=0;
	$msg='';
    $request_fields = array('task_email','task_homeaddress','task_newaddress','task_description','task_budget','task_latitude','task_longitude','task_sel');
    
	 foreach($request_fields as $request_field)
 		{
  			if(isset($params[$request_field])){
   				$data[$request_field]=$params[$request_field];

  			}
		 }
	$data['task_date']=date("d/m/Y");
	$data['task_budget']="$".$params['task_budget'];
	$data['completed_id']='0';
	$query=$this->db->insert('tasks',$data);
	if($this->db->insert_id()>0){
		$msg="Your new task posted successfully!";
		$status=1;
	}else{
		$msg="Your new task posted invalid!";
	}
	$result['status']=$status;
	$result['msg']=$msg;
	$result['posted_task']=$data;
	return $result;
}

public function search_task($params){
	$result=array();
	$data=array();
	$data1=array();
	$data2=array();
	$distance=0;
	$status=1;
	$msg='succes';
  	$request_fields = array('worker_email','worker_latitude','worker_longitude');
	 foreach($request_fields as $request_field)
 		{
  			if(isset($params[$request_field])){
   				$data[$request_field]=$params[$request_field];
  			}
		 }	
	$query_all_task=$this->db->get_where('tasks',array('task_sel'=>'0'));
	$task_amount=$query_all_task->num_rows();
	for($i=0;$i<$task_amount;$i++){
	$data1[$i]=$query_all_task->row_array($i);
	$data1_temp=$data1[$i]; 
	$task_fields=array('task_id','task_email','task_budget','task_description','task_latitude','task_longitude','completed_id');
	foreach ($task_fields as  $task_field) {
  			if(isset($data1_temp[$task_field])){
   				$data2[$task_field]=$data1_temp[$task_field];
  			}			  
		}
	$distance=round($this->distance($data2['task_latitude'],$data2['task_longitude'],$data['worker_latitude'],$data['worker_longitude'],"K"))."Km";
	$data3['task_id']=$data2['task_id'];
	$data3['task_email']=$data2['task_email'];
	$data3['task_budget']="$".$data2['task_budget'];
	$data3['task_distance']=$distance;
	$data3['task_description']=$data2['task_description'];
	$data3['completed_id']=$data2['completed_id'];
	
	$query_task=$this->db->get_where('tasks',array('task_email'=>$data2['task_email'],'task_id'=>$data2['task_id']));
	if($query_task->num_rows()>0){
	$query_task_info=$query_task->row_array();
	$data3['task_newaddress']=$query_task_info['task_newaddress'];
	}
	
	$query_client=$this->db->get_where('users',array('user_email'=>$data2['task_email']));
	if($query_client->num_rows()>0){
	$query_client_info=$query_client->row_array();
	$data3['client_firstname']=$query_client_info['user_firstname'];
	$data3['client_lastname']=$query_client_info['user_lastname'];
	$data3['client_photo']=$query_client_info['user_photo'];
	$data3['client_phonenumber']=$query_client_info['user_phonenumber'];


	}
	
	$data1[$i]=$data3;

	}
	$result['index']=$task_amount;
	$result['status']=$status;
	$result['msg']=$msg;
	$result['posted_data']=$data1;
	return $result;
}

// Calculate the distance between two points from latitude and longitude///////
public function distance($lat1, $lon1, $lat2, $lon2, $unit) {
  $theta = $lon1-$lon2;
  $dist = sin(deg2rad($lat1)) * sin(deg2rad($lat2)) +  cos(deg2rad($lat1)) * cos(deg2rad($lat2)) * cos(deg2rad($theta));
  $dist = acos($dist);
  $dist = rad2deg($dist);
  $miles = $dist * 60 * 1.1515;
  $unit = strtoupper($unit);
  if ($unit == "K") {
    return ($miles * 1.609344);
  } else if ($unit == "N") {
      return ($miles * 0.8684);
    } else {
        return $miles;
      }
}



public function view_task($params){
	$result=array();
	$data=array();
	$data1=array();
	$data2=array();
	$status=1;
	$msg='succes';
	$j=0;
	
	$query = $this->db->get_where('tasks');
	
	$rowcount = $query->num_rows();
	
	for($i=0;$i<$rowcount;$i++){
	
	$data1[$i]=$query->row_array($i);
	$data1_temp=$data1[$i];
	
	$task_fields=array('task_id','task_email','task_budget','task_description','task_homeaddress','task_newaddress','task_latitude','task_longitude','task_date','completed_id');
	foreach ($task_fields as  $task_field) {
  			if(isset($data1_temp[$task_field])){
   				$data2[$task_field]=$data1_temp[$task_field];
  			}			  
		}
	
	
	if($data2['task_email']==$params['user_email']){
	$data3[$j]=$data2;
	++$j;
	}
	
	}
	$result['status']=$status;
	$result['msg']=$msg;
	$result['post_task']=$data3;
	return $result;
}	


public function post_proposal($params){
	$result=array();
	$data=array();
	$status=0;
	$msg='';
     	$request_fields = array('worker_email','task_id');
    
	 foreach($request_fields as $request_field)
 		{
  			if(isset($params[$request_field])){
   				$data[$request_field]=$params[$request_field];

  			}
		 }
	$data['proposal_date']=date("d/m/Y");
	$query=$this->db->insert('proposals',$data);
	if($this->db->insert_id()>0){
		$msg="Your proposal successfully!";
		$status=1;
	}else{
		$msg="Your proposal invalid!";
	}
	$result['status']=$status;
	$result['msg']=$msg;
	$result['posted_task']=$data;
	return $result;
}


public function view_proposal($params){
	$result=array();
	$data=array();
	$data1=array();
	$data2=array();
	$data3=array();
	$status=1;
	$msg='succes';
	$j=0;
	
	$query = $this->db->get_where('proposals');
	
	$rowcount = $query->num_rows();

	
	for($i=0;$i<$rowcount;$i++){
	
	$data1[$i]=$query->row_array($i);
	$data1_temp=$data1[$i];
	
	$task_fields=array('proposal_id','worker_email','task_id','proposal_date');
	foreach ($task_fields as  $task_field) {
  			if(isset($data1_temp[$task_field])){
   				$data2[$task_field]=$data1_temp[$task_field];
  			}			  
		}
	if($data2['task_id']==$params['task_id']){
	$data3[$j]=$data2;
	++$j;
	}
	
	}
	
	for($k=0;$k<$j;$k++){
	$data3_temp=$data3[$k];	
	$data4=$data3_temp['worker_email'];
	$data5[$k]=$this->get_info($data4);
	
	}
	
	$result['status']=$status;
	$result['msg']=$msg;
	$result['view_proposals']=$data5;
	return $result;
}	




public function get_clientinfo($params){
		$result = array();
		$status = 0;
		$data=array();
		$msg = '';
		$query = $this->db->get_where('users', array('user_email'=>$params['client_email']));
		if($query->num_rows() > 0){
		$data=$query->row_array();
		$status=1;
		$msg='success';
		}else{
			$status = 2;
			$msg = 'Invalid email or password.';
		}
		$result['status'] = $status;
		$result['msg'] = $msg;
		$result['client_info']=$data;
		return $result;
	}
	
public function user_rate_view($params){
		$result = array();
		$status = 0;
		$data=array();
		$msg = '';
		$query = $this->db->get_where('users_report', array('user_email'=>$params['user_email']));
		if($query->num_rows() > 0){
		$data=$query->row_array();
		$status=1;
		$msg='success';
		}else{
			$status = 2;
			$msg = 'Invalid user email.';
		}
		$result['status'] = $status;
		$result['msg'] = $msg;
		$result['user_rate']=$data;
		return $result;
	}	

public function user_rate_update($params){
		$result = array();
		$status = 0;
		$data=array();
		$msg = '';
		$request_fields = array('user_email','user_rate','task_budget');

		$query = $this->db->get_where('users_report', array('user_email'=>$params['user_email']));
		if($query->num_rows() > 0){
		$data_temp=$query->row_array();
		$data['task_nums']=$data_temp['task_nums']+1;
		$data['user_rate']=round((($data_temp['user_rate']*$data_temp['task_nums'])+$params['user_rate'])/$data['task_nums'],1);
		$ddate = date('Y-m-d');
		$date = new DateTime($ddate);
		$week = $date->format("W");
		$data['current_week']=$week;
		if($data['current_week']==$data_temp['current_week']){

		$data['last_task']=$params['task_budget'];
		$data['this_week']=($data_temp['this_week']+$params['task_budget']);
		
		
		
		}else{
		$data['last_task']=$params['task_budget'];
		$data['this_week']=$params['task_budget'];
		}
		
		$query = $this->db->update('users_report', array('task_nums'=>$data['task_nums'],'user_rate'=>$data['user_rate'],'current_week'=>$data['current_week'],'last_task'=>$data['last_task'],'this_week'=>$data['this_week']), array('user_email'=>$params['user_email']));


		$status=1;
		$msg='success';
		}else{
		$data['user_email']=$params['user_email'];
		$data['task_nums']=1;
		$data['user_rate']=$params['user_rate'];
		
		$ddate = date('Y-m-d');
		$date = new DateTime($ddate);
		$week = $date->format("W");
		
		$data['current_week']=$week;
		$data['last_task']=$params['task_budget'];
		$data['this_week']=$params['task_budget'];
		
		$this->db->insert('users_report',$data);
		
		$status=1;
		$msg='success';
		}
		$result['status'] = $status;
		$result['msg'] = $msg;
		$result['user_rate']=$data;
		return $result;
	}
	

public function completedID_update($params){
		$result = array();
		$status = 0;
		$msg = '';
		$query = $this->db->get_where('tasks', array('task_id'=>$params['task_id']));
		if($query->num_rows() > 0){
		$status=1;
		$msg='success';
		$query = $this->db->update('tasks', array('completed_id'=>'1'), array('task_id'=>$params['task_id']));
		}else{
		$status = 2;
		$msg = 'completedID update Invalided.';
		}
		$result['status'] = $status;
		$result['msg'] = $msg;
		return $result;
	}
	
	
public function send_email($params) {
	$result=array();
	$status=0;
	$msg=''; 
         $from_email = $params['from_email']; 
         $to_email = $params['to_email']; 
   
         //Load email library 
         $this->load->library('email'); 
   
         $this->email->from($from_email, 'Dooglee Account'); 
         $this->email->to($to_email);
         $this->email->subject('Attention from Dooglee!'); 
         $this->email->message($params['email_content']); 
   
         //Send mail 
         if($this->email->send()){
         $status=1;
         $msg='Email sent successfully.';
         }else{
         $status=2;
         $msg='Error in sending Email.';
         } 
         $result['status']=$status;
         $result['msg']=$msg;
         return $result;
      } 
		
	
	
public function get_info($params){
		$result = array();
		$status = 0;
		$data=array();
		$msg = '';
		$query = $this->db->get_where('users', array('user_email'=>$params));
		if($query->num_rows() > 0){
		$data=$query->row_array();
		$status=1;
		$msg='success';
		}else{
			$status = 2;
			$msg = 'Invalid email or password.';
		}
		return $data;
	}

}
