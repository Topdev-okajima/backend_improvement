<div class="container-wrapper">
	<div class="container">
	
		<h1><center>Welcome to Dooglee</center></h1>
    </div>
</div>
<div style="background-color:#222222; opacity:0.5; border-radius: 15px; float:left; width: 40%; margin: 100px 0 0 50px; height: 500px;">
	< img style = "height: 100%;" src="" />
</div>
<div class="be-clear"></div>