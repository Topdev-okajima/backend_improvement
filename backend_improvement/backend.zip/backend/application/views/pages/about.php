	<div class="container be-container-home">
		<div class="col-xs-12">
          	<div class="col-xs-12 col-sm-5 be-container-left-hidden text-left">
          		<div class="be-container-home-left"></div>
          	</div>
          	<div class="col-xs-12 col-sm-7">
          		<div class="be-container-about">
	          		<div class="be-font-s24">
	          			<span class="be-font-s54">A</span>bout us
					</div>
					<div class="be-font-s24 margin-top-20">Benefits of joining Looksie</div>
					<div class="be-font-s16 margin-top-10">
						We will promote your looksie images to artists that show interest in similar looksie images (based on genres, language, and other factors), we will provide tools to determine what’s popular and what’s not, with ratings and other relevant data.
						You will be able to engage with your artists, and let them follow you on other social platforms. Best part? All of it is free.
					</div>
					<div class="be-font-s24 margin-top-30">How does it work?</div>
					<div class="be-font-s16 margin-top-10">
						Our app is set to launch soon, and will be a major player in the looksie images industry.
						Our platform is designed to promote the natural selection of looksie images, by finally allowing artists to have a say in what’s considered popular and what isn't.
						Your looksie images could reach thousands of artists who will act as your judges.
					</div>
				</div>
          	</div>
        </div>
		<div class="clear"></div>
	</div>